package doxygen_csharp;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.xml.sax.SAXException;

import com.change_vision.jude.api.inf.editor.BasicModelEditor;
import com.change_vision.jude.api.inf.editor.ModelEditorFactory;
import com.change_vision.jude.api.inf.exception.InvalidEditingException;
import com.change_vision.jude.api.inf.exception.ProjectNotFoundException;
import com.change_vision.jude.api.inf.model.IAssociation;
import com.change_vision.jude.api.inf.model.IAttribute;
import com.change_vision.jude.api.inf.model.IClass;
import com.change_vision.jude.api.inf.model.IElement;
import com.change_vision.jude.api.inf.model.IModel;
import com.change_vision.jude.api.inf.model.INamedElement;
import com.change_vision.jude.api.inf.model.IOperation;
import com.change_vision.jude.api.inf.model.IPackage;

/**
 * 
 * this class is the tag of **.xml
 *  the tag is <memberdef>. the class is named Member
 *  the tag is <memberdef kind>.it is named "kind"
 *  the kind type is "function","variable","property","enum"
 *  the tag is <memberdef prot>.it is named "prot"
 *  the tag is <memberdef static>.it is named "staticBoolean"
 *  the tag is <memberdef const>.it is named "constBoolean"
 *  the tag is <memberdef virt>.it is named "virt"
 *  the sub-tag is <name>.it is named "name"
 *  the sub-tag is <type>.it is named "type"
 *  the type's sub-tag is <type ref>.it is named "typeRef"
 *  the sub-tag is <argsstring>.it is named "argsstring"
 *  the sub-tag is <initializer>.it is named "initializer"
 *  the initializer's sub-tag is <initializer ref">.it is named "initializerRef"
 *  the sub-tag is <detaileddescription>.it is named "detaileddescription"
 *  the tag is <memberdef gettable>.it is named "gettable"
 *  the tag is <memberdef settable>.it is named "settable"
 *  memberParaList is the list of the Param.tag is <param>
 *  enumValues is the list of the EnumValue.tag is <enumvalue>
 *  Parent is the Section relation
 *  it's have Astah C#'field.
 *  const,override,readonly,delegate,sealed,internal,unsafe,virtual,abstract
 */
public abstract class Member implements IConvertToJude {
	String kind;
	String prot;
	String staticBoolean;
	String constBoolean;
	String virt;
	String name;
	String type;
	Ref typeRef;
	String argsstring;
	String initializer;
	Ref initializerRef;
	String detaileddescriptionPara;
	String gettable;
	String settable;
	Vector memberParaList;
	Vector enumValues;
	Section parent;
	
	public static final Map TYPEDEFS = new HashMap();
	
	public static final String KIND_FUNCTION = "function";

	public static final String KIND_ATTRIBUTE = "variable";
	
	public static final String KIND_PROPERTY = "property";
	
	public static final String KIND_ENUM = "enum";
	
	public static final String KIND_EVENT = "event";
	
	public static final String AND = "&";
	
	public static final String STAR = "*";
	
	public Section getParent() {
		return parent;
	}

	public void setParent(Section parent) {
		this.parent = parent;
	}

	public Member() {
		enumValues = new Vector();
		memberParaList = new Vector();
	}

	public void addEnum(EnumValue newEnum) {
		enumValues.add(newEnum);
	}

	public Vector getEnums() {
		return enumValues;
	}

	public void setEnums(Vector enums) {
		this.enumValues = enums;
	}

	public String getConstBoolean() {
		return constBoolean;
	}

	public void setConstBoolean(String constBoolean) {
		this.constBoolean = constBoolean;
	}

	public String getArgsstring() {
		return argsstring;
	}

	public void setArgsstring(String argsstring) {
		this.argsstring = argsstring;
	}

	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getProt() {
		return prot;
	}

	public void setProt(String prot) {
		this.prot = prot;
	}

	public String getStaticBoolean() {
		return staticBoolean;
	}

	public void setStaticBoolean(String staticBoolean) {
		this.staticBoolean = staticBoolean;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getInitializer() {
		return initializer;
	}

	public void setInitializer(String initializer) {
		this.initializer = initializer;
	}

	public String getDetaileddescriptionPara() {
		return detaileddescriptionPara;
	}

	public void setDetaileddescriptionPara(String detaileddescriptionPara) {
		this.detaileddescriptionPara = detaileddescriptionPara;
	}

	public String getGettable() {
		return gettable;
	}

	public void setGettable(String gettable) {
		this.gettable = gettable;
	}

	public String getSettable() {
		return settable;
	}

	public void setSettable(String settable) {
		this.settable = settable;
	}
	
	public Ref getInitializerRef() {
		return initializerRef;
	}

	public void setInitializerRef(Ref initializerRef) {
		this.initializerRef = initializerRef;
	}

	public Vector getMemberParaList() {
		return memberParaList;
	}

	public void setMemberParaList(Vector memberParaList) {
		this.memberParaList = memberParaList;
	}

	public void addMemberParam(Param memberParam){
		memberParaList.add(memberParam);
	}

	public Ref getTypeRef() {
		return typeRef;
	}

	public void setTypeRef(Ref typeRef) {
		this.typeRef = typeRef;
	}
	
	public String getVirt() {
		return virt;
	}

	public void setVirt(String virt) {
		this.virt = virt;
	}
	
	public Vector getEnumValues() {
		return enumValues;
	}

	public void setEnumValues(Vector enumValues) {
		this.enumValues = enumValues;
	}
	
	public String getIClassFullName(IClass cls) {
		StringBuffer fullname = new StringBuffer();
		IElement owner = cls.getOwner();
		while (true) {
			if (owner instanceof IModel || owner == null) {
				break;
			} else {
				fullname.insert(0, ((INamedElement) owner).getName());
				fullname.append("::");
				owner = owner.getOwner();
			}
		}
		fullname.append("::");
		fullname.append(cls.getName());
		return fullname.toString();
	}
	
	public void convertToJudeModel(IElement parent, File[] files) throws InvalidEditingException,
			ClassNotFoundException, ProjectNotFoundException, IOException, SAXException {
		BasicModelEditor basicModelEditor = ModelEditorFactory.getBasicModelEditor();
		if (KIND_ATTRIBUTE.equals(this.getKind())) {
			convertToAttributeOrOperation(parent, basicModelEditor);
		} else if (KIND_FUNCTION.equals(this.getKind())) {
			convertToAttributeOrOperation(parent, basicModelEditor);
		} else if (KIND_PROPERTY.equals(this.getKind())) {
			convertToAttributeOrOperation(parent, basicModelEditor);
		} else if (KIND_ENUM.equals(this.getKind())) {
			convertToEnum(parent, files);
		} else if(KIND_EVENT.equals(this.getKind())){
			convertToAttributeOrOperation(parent, basicModelEditor);
		} else if ("typedef".equals(this.getKind())) {
			String[] split = getType().split(" ");
			TYPEDEFS.put(getName(), split[split.length - 1]);
		} else {
			System.out.println("NO DEAL(KIND)= " + this.getKind());
		}
	}

	protected void convertToEnum(IElement parent, File[] files)
			throws ProjectNotFoundException, ClassNotFoundException,
			InvalidEditingException, IOException, SAXException {
		IClass enumClass;
		if (parent instanceof IPackage) {
			enumClass = Tool.getClass(((IPackage) parent), getName(), null);
		} else {
			enumClass = Tool.getClass(((IClass) parent), getName());
		}
		enumClass.addStereotype("enum");
		for (Iterator iterator = enumValues.iterator(); iterator.hasNext();) {
			EnumValue enumValue = (EnumValue) iterator.next();
			enumValue.convertToJudeModel(enumClass, files);
		}
	}

	public static String getTypeFromTypeDef(String name) {
		String type = name;
		while ((type = (String) TYPEDEFS.get(type)) != null) {
			name = type;
		}
		return name;
	}

	protected void convertToAttributeOrOperation(IElement parent,
			BasicModelEditor basicModelEditor) throws InvalidEditingException,
			ProjectNotFoundException, ClassNotFoundException, IOException {
		if (getType() != null && !"".equals(getType())) {
			String array = getArrayString();
			Object[] result = filterKeyword(type);
			Set keywords = (Set) result[0];
			String type = ((String) result[1]).trim();
			if ("".equals(type) && typeRef != null) {
				type = typeRef.value;
			}
			String filteredType = getTypeFromTypeDef(type);
			String[] splits = (filteredType + array).split(" ");
			if (KIND_ATTRIBUTE.equals(this.getKind())) {				
				convertAttri(parent, basicModelEditor, keywords, splits);
			} else if (KIND_FUNCTION.equals(this.getKind()) || KIND_EVENT.equals(this.getKind())) {
				convertOper(parent, basicModelEditor, keywords, splits);
			} else if (KIND_PROPERTY.equals(this.getKind())) {
				convertAttri(parent, basicModelEditor, keywords, splits);
			}
		} else if (getTypeRef() != null) {
			if (KIND_ATTRIBUTE.equals(this.getKind())) {
				//if is static, create attribute
				if (!"no".equals(this.getStaticBoolean())
						|| Config.getClassNameAboutForbidCreateAssociation().contains(getTypeRef().getValue())
						|| Config.getClassNameAboutForbidCreateAssociation().contains(getIClassFullName((IClass) parent))) {
					generateAttri(parent, basicModelEditor, (IClass) CompoundDef.compounddef.get(getTypeRef().getRefid()));
				} else {
					//if not, create association
					generateAssoication((IClass) parent, basicModelEditor, (IClass) CompoundDef.compounddef.get(getTypeRef().getRefid()));
				}
			} else if (KIND_PROPERTY.equals(this.getKind())) {
				generateAttri(parent, basicModelEditor, (IClass) CompoundDef.compounddef.get(getTypeRef().getRefid()));
			}else {
				generateOper(parent, basicModelEditor, (IClass) CompoundDef.compounddef.get(getTypeRef().getRefid()));
			}
		} else if (getType() != null && "".equals(getType()) && getTypeRef() == null) {
			if (KIND_FUNCTION.equals(this.getKind()) || KIND_EVENT.equals(this.getKind())) {
				IOperation oper = generateOper(parent, basicModelEditor, (IClass) null);
				if (KIND_EVENT.equals(this.getKind())) {
					oper.addStereotype("event");
				}
			}
		}
	}

	private void convertOper(IElement parent,
			BasicModelEditor basicModelEditor, Set keywords, String[] splits)
			throws InvalidEditingException, ProjectNotFoundException,
			ClassNotFoundException {
		IOperation oper = null;
		if (splits.length > 1) {
			StringBuffer sb = new StringBuffer();
			for (int i = 1; i < splits.length; i++) {
				sb.append(splits[i]);
			}
			int endIndex = sb.toString().indexOf(">");
			if (splits[0].endsWith("<") && (endIndex != -1)) {
				String clsName = splits[0].substring(0, splits[0].length() - 1);
				String[] splits2 = clsName.split("\\.");
				splits2[splits2.length - 1] += "<" + sb.toString().substring(0, endIndex) + ">";
				oper = generateOper(parent, basicModelEditor, splits2);
			} else {
				oper = generateOper(parent, basicModelEditor, splits[0].split("\\."));					
			}
		} else {
			oper = generateOper(parent, basicModelEditor, splits[0].split("\\."));
		}
		dealOperationKeyword(basicModelEditor, keywords, oper);
		
		for (Iterator iterator = memberParaList.iterator(); iterator.hasNext();) {
			Param param = (Param) iterator.next();
			param.convertToJudeModel(oper,null);
		}
	}
	
	private void convertAttri(IElement parent,
			BasicModelEditor basicModelEditor, Set keywords, String[] splits)
			throws InvalidEditingException, ProjectNotFoundException,
			ClassNotFoundException {
		IAttribute attr = null;
		if (splits.length > 1) {
			StringBuffer sb = new StringBuffer();
			for (int i = 1; i < splits.length; i++) {
				sb.append(splits[i]);
			}
			int endIndex = sb.toString().indexOf(">");
			if (splits[0].endsWith("<") && (endIndex != -1)) {
				String clsName = splits[0].substring(0, splits[0].length() - 1);
				String[] splits2 = clsName.split("\\.");
				splits2[splits2.length - 1] += "<" + sb.toString().substring(0, endIndex) + ">";
				attr = generateAttri(parent, basicModelEditor, splits2);
			} else {
				attr = generateAttri(parent, basicModelEditor, splits[0].split("\\."));					
			}
		} else {
			attr = generateAttri(parent, basicModelEditor, splits[0].split("\\."));
		}
		correctProperty(basicModelEditor, attr);
		dealAttributeKeywords(basicModelEditor, keywords, attr);
	}
	
 	private void correctProperty(BasicModelEditor basicModelEditor, IAttribute attr) throws InvalidEditingException {
		if (KIND_PROPERTY.equals(this.getKind())) {
			if (!Arrays.asList(attr.getStereotypes()).contains("property")) {
				attr.addStereotype("property");
				if ("yes".equals(settable)) {
					basicModelEditor.createTaggedValue(attr, "jude.c_sharp.property_set", "true");
				} else {
					basicModelEditor.createTaggedValue(attr, "jude.c_sharp.property_set", "false");
				}
				if ("yes".equals(gettable)) {
					basicModelEditor.createTaggedValue(attr, "jude.c_sharp.property_get", "true");
				} else {
					basicModelEditor.createTaggedValue(attr, "jude.c_sharp.property_get", "false");
				}
			}
		}
	}
	
	abstract void dealOperationKeyword(BasicModelEditor basicModelEditor,
			Set keywords, IOperation fun) throws InvalidEditingException;
	
	abstract void dealAttributeKeywords(BasicModelEditor basicModelEditor,
			Set keywords, IAttribute attr) throws InvalidEditingException;

	abstract Object[] filterKeyword(String type);
	
	IOperation generateOper(IElement parent,
			BasicModelEditor basicModelEditor,
			IClass type) throws InvalidEditingException,
			ProjectNotFoundException, ClassNotFoundException {
		IOperation oper = Tool.getOperation((IClass) parent, name, type);
		oper.setVisibility(this.getProt());
		oper.setStatic(!"no".equals(this.getStaticBoolean()));
		if(this.getDetaileddescriptionPara()!=null){
			oper.setDefinition(this.getDetaileddescriptionPara());
		}
		for (Iterator iterator = memberParaList.iterator(); iterator.hasNext();) {
			Param param = (Param) iterator.next();
			param.convertToJudeModel(oper,null);
		}
		return oper;
	}
	
	IOperation generateOper(IElement parent,
			BasicModelEditor basicModelEditor,
			String[] path) throws InvalidEditingException,
			ProjectNotFoundException, ClassNotFoundException {
		String[] namespace = new String[] {};
		if (path.length > 1) {
			namespace = new String[path.length - 1];
			System.arraycopy(path, 0, namespace, 0, path.length - 1);
		}
		IOperation oper;
		if (LanguageManager.getCurrentLanguagePrimitiveType().contains(path[0])) {
			oper = Tool.getOperation((IClass) parent, name, path[0]);
		} else {
			oper = Tool.getOperation((IClass) parent, name
					, path.length > 0 ? path[path.length -1] : getType());
		}
		oper.setVisibility(this.getProt());
		oper.setStatic(!"no".equals(this.getStaticBoolean()));
		if(this.getDetaileddescriptionPara()!=null){
			oper.setDefinition(this.getDetaileddescriptionPara());
		}

		return oper;
	}
	
	void generateAttri(IElement parent,
			BasicModelEditor basicModelEditor,
			IClass type) throws InvalidEditingException,
			ProjectNotFoundException, ClassNotFoundException {
		IAttribute attr = Tool.getAttribute((IClass) parent, name, type);
		int [][]range = getMultiRange();
		if (range != null) {
			attr.setMultiplicity(range);
		}
		attr.setChangeable(!"no".equals(this.getConstBoolean()));
		attr.setVisibility(this.getProt());
		attr.setStatic(!"no".equals(this.getStaticBoolean()));
		if(this.getDetaileddescriptionPara()!=null){
			attr.setDefinition(this.getDetaileddescriptionPara());
		}
		attr.setInitialValue(this.getInitializer());
		correctProperty(basicModelEditor, attr);
	}
	
	IAttribute generateAttri(IElement parent,
			BasicModelEditor basicModelEditor,
			String[] path) throws InvalidEditingException,
			ProjectNotFoundException, ClassNotFoundException {
		String[] namespace = new String[] {};
		if (path.length > 1) {
			namespace = new String[path.length - 1];
			System.arraycopy(path, 0, namespace, 0, path.length - 1);
		}
		IAttribute attr;
		if (LanguageManager.getCurrentLanguagePrimitiveType().contains(path[0])) {
			attr = Tool.getAttribute((IClass) parent, name, path[0]);
		} else {
			attr = Tool.getAttribute((IClass) parent, name
					, path.length > 0 ? path[path.length -1] : getType());
		}
		attr.setChangeable(!"no".equals(this.getConstBoolean()));
		attr.setVisibility(this.getProt());
		attr.setStatic(!"no".equals(this.getStaticBoolean()));
		if(this.getDetaileddescriptionPara()!=null){
			attr.setDefinition(this.getDetaileddescriptionPara());
		}
		attr.setInitialValue(this.getInitializer());

		return attr;
	}

	void generateAssoication(IClass parent,
			BasicModelEditor basicModelEditor,
			IClass assocEnd) throws InvalidEditingException,
			ProjectNotFoundException, ClassNotFoundException {
		IAssociation attr = basicModelEditor.createAssociation(parent
				, assocEnd
				, name
				, ""
				, "");
		attr.setVisibility(this.getProt());
		if(this.getDetaileddescriptionPara()!=null){
			attr.setDefinition(this.getDetaileddescriptionPara());
		}
	}	
	
	String getArrayString() {
		String arrayString = "";
		if (type.indexOf("[") >= 0) {			
			arrayString = type;
		} else if (this.argsstring.indexOf("[") == 0) {
			arrayString = this.argsstring;
		}
		if (!"".equals(arrayString)) {
			int start = arrayString.indexOf("[");
			int end = arrayString.lastIndexOf("]");
			return arrayString.substring(start, end + 1);
		}
		return arrayString;
	}
	
	int[][] getMultiRange() {
		StringBuffer buffer = new StringBuffer();
		int length = 0;
		String arrayString;
		if (type.indexOf("[") >= 0) {
			arrayString = type;
		} else if (this.argsstring.indexOf("[") >= 0) {
			arrayString = this.argsstring;
		} else {
			return null;
		}
		while (arrayString.indexOf("[") >= 0) {
			int beginIndex = arrayString.indexOf("[");
			int endIndex = arrayString.indexOf("]");
			if (endIndex - beginIndex >= 1) {
				String num = arrayString.substring(beginIndex + 1, endIndex);
				try {
					Integer.parseInt(num);
				} catch (NumberFormatException e) {
					return null;
				}
				buffer.append(num);
				buffer.append(" ,");
				length++ ;
			}
			arrayString = arrayString.substring(endIndex + 1);
		}		
		if (length == 0) {
			return null;
		}
		String[] mliti = buffer.toString().split(",");
		int[][] range = new int[length][1];
		for (int i = 0; i < length; i++) {
			int value = "".equals(mliti[i].trim()) ? -100 : Integer.valueOf(mliti[i].trim()).intValue();
			range[i][0] = value;
		}
		return range;		
	}
}