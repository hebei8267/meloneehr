package doxygen_cplus;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.xml.sax.SAXException;

import com.change_vision.jude.api.inf.editor.BasicModelEditor;
import com.change_vision.jude.api.inf.editor.ModelEditorFactory;
import com.change_vision.jude.api.inf.exception.InvalidEditingException;
import com.change_vision.jude.api.inf.exception.ProjectNotFoundException;
import com.change_vision.jude.api.inf.model.IAssociation;
import com.change_vision.jude.api.inf.model.IAttribute;
import com.change_vision.jude.api.inf.model.IClass;
import com.change_vision.jude.api.inf.model.IElement;
import com.change_vision.jude.api.inf.model.IModel;
import com.change_vision.jude.api.inf.model.INamedElement;
import com.change_vision.jude.api.inf.model.IOperation;
import com.change_vision.jude.api.inf.model.IParameter;

/**
 * 
 * this class is the tag of **.xml
 *  the tag is <memberdef>. the class is named Member
 *  the tag is <memberdef kind>.it is named "kind"
 *  the tag is <memberdef id>.it is named "id"
 *  the kind type is "function","variable","property","enum"
 *  the tag is <memberdef prot>.it is named "prot"
 *  the tag is <memberdef static>.it is named "staticBoolean"
 *  the tag is <memberdef const>.it is named "constBoolean"
 *  the tag is <memberdef virt>.it is named "virt"
 *  the sub-tag is <name>.it is named "name"
 *  the sub-tag is <type>.it is named "type"
 *  the type's sub-tag is <type ref>.it is named "typeRef"
 *  the sub-tag is <argsstring>.it is named "argsstring"
 *  the sub-tag is <initializer>.it is named "initializer"
 *  the initializer's sub-tag is <initializer ref">.it is named "initializerRef"
 *  the sub-tag is <detaileddescription>.it is named "detaileddescription"
 *  the tag is <memberdef gettable>.it is named "gettable"
 *  the tag is <memberdef settable>.it is named "settable"
 *  memberParaList is the list of the Param.tag is <param>
 *  enumValues is the list of the EnumValue.tag is <enumvalue>
 *  Parent is the Section relation
 *  it's have Astah C#'field.
 *  const,override,readonly,delegate,sealed,internal,unsafe,virtual,abstract
 */
public abstract class Member implements IConvertToJude {
	String kind;
	String id;
	String prot;
	String staticBoolean;
	String constBoolean;
	String virt;
	String explicit;
	String inline;
	String mutable;
	String name;
	String type;
	Ref typeRef;
	String argsstring;
	String initializer;
	Ref initializerRef;
	StringBuffer detaileddescriptionParas = new StringBuffer();	
	String briefdescriptionPara;
	String gettable;
	String settable;
	Vector memberParaList;
	Vector enumValues;
	Section parent;
	
	public static final Map TYPEDEFS = new HashMap();
	
	public static final String KIND_FUNCTION = "function";
	
	public static final String KIND_SIGNAL = "signal";
	
	public static final String KIND_SLOT = "slot";

	public static final String KIND_ATTRIBUTE = "variable";
	
	public static final String KIND_PROPERTY = "property";
	
	public static final String KIND_ENUM = "enum";
	
	public static final String KIND_EVENT = "event";
	
	public static final String KIND_FRIEND = "friend";
	
	public static final String CONST = "const";
	
	public static final String AND = "&";
	
	public static final String STAR = "*";
	
	public static final String KEYWORD_ARRAY = "array";
	
	public Section getParent() {
		return parent;
	}

	public void setParent(Section parent) {
		this.parent = parent;
	}

	public Member() {
		enumValues = new Vector();
		memberParaList = new Vector();
	}

	public void addEnum(EnumValue newEnum) {
		enumValues.add(newEnum);
	}

	public Vector getEnums() {
		return enumValues;
	}

	public void setEnums(Vector enums) {
		this.enumValues = enums;
	}

	public String getConstBoolean() {
		return constBoolean;
	}

	public void setConstBoolean(String constBoolean) {
		this.constBoolean = constBoolean;
	}

	public String getArgsstring() {
		return argsstring;
	}

	public void setArgsstring(String argsstring) {
		this.argsstring = argsstring;
	}

	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getProt() {
		return prot;
	}

	public void setProt(String prot) {
		this.prot = prot;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public String getStaticBoolean() {
		return staticBoolean;
	}

	public void setStaticBoolean(String staticBoolean) {
		this.staticBoolean = staticBoolean;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getInitializer() {
		return initializer;
	}

	public void setInitializer(String initializer) {
		this.initializer = initializer;
	}
	
	public String getBriefdescriptionPara() {
		return briefdescriptionPara;
	}

	public void setBriefdescriptionPara(String briefdescriptionPara) {
		this.briefdescriptionPara = briefdescriptionPara + "\n\n";
	}

	public String getDetaileddescriptionPara() {
		return detaileddescriptionParas.toString();
	}

	public void setDetaileddescriptionPara(String detaileddescriptionPara) {
		this.detaileddescriptionParas.append(detaileddescriptionPara + "\n\n");
	}

	public String getGettable() {
		return gettable;
	}

	public void setGettable(String gettable) {
		this.gettable = gettable;
	}

	public String getSettable() {
		return settable;
	}

	public void setSettable(String settable) {
		this.settable = settable;
	}
	
	public Ref getInitializerRef() {
		return initializerRef;
	}

	public void setInitializerRef(Ref initializerRef) {
		this.initializerRef = initializerRef;
	}

	public Vector getMemberParaList() {
		return memberParaList;
	}

	public void setMemberParaList(Vector memberParaList) {
		this.memberParaList = memberParaList;
	}

	public void addMemberParam(Param memberParam){
		memberParaList.add(memberParam);
	}

	public Ref getTypeRef() {
		return typeRef;
	}

	public void setTypeRef(Ref typeRef) {
		this.typeRef = typeRef;
	}
	
	public String getVirt() {
		return virt;
	}

	public void setVirt(String virt) {
		this.virt = virt;
	}
	
	public String getExplicit() {
		return explicit;
	}

	public void setExplicit(String explicit) {
		this.explicit = explicit;
	}
	
	public String getInline() {
		return inline;
	}

	public void setInline(String inline) {
		this.inline = inline;
	}
	
	public String getMutable() {
		return mutable;
	}

	public void setMutable(String mutable) {
		this.mutable = mutable;
	}
	
	public Vector getEnumValues() {
		return enumValues;
	}

	public void setEnumValues(Vector enumValues) {
		this.enumValues = enumValues;
	}
	
	public String getIClassFullName(IClass cls) {
		StringBuffer fullname = new StringBuffer();
		IElement owner = cls.getOwner();
		while (true) {
			if(owner instanceof IModel|| owner == null){
				break;
			}else{
				fullname.insert(0, ((INamedElement) owner).getName());
				fullname.append("::");
				owner = owner.getOwner();	
			}
		}
		fullname.append(cls.getName());
		return fullname.toString();
	}
	
	public IElement convertToJudeModel(IElement parent, File[] files) throws InvalidEditingException,
			ClassNotFoundException, ProjectNotFoundException, IOException, SAXException {
		BasicModelEditor basicModelEditor = ModelEditorFactory.getBasicModelEditor();
		if (KIND_ATTRIBUTE.equals(this.getKind())) {
			convertToAttribute(parent, basicModelEditor);
		} else if (KIND_FUNCTION.equals(this.getKind())
				|| KIND_SIGNAL.equals(this.getKind())
				|| KIND_SLOT.equals(this.getKind())) {
			convertToFunction(parent, files, basicModelEditor);
		} else if (KIND_PROPERTY.equals(this.getKind())) {
			convertToAttribute(parent, basicModelEditor);
		} else if (KIND_ENUM.equals(this.getKind())) {
			convertToEnum(parent, files);
		} else if(KIND_EVENT.equals(this.getKind())){
			convertToFunction(parent, files, basicModelEditor);
		} else if (KIND_FRIEND.equals(this.getKind())
				&& argsstring.indexOf("(") != -1) {
			convertToFunction(parent, files, basicModelEditor);
		} else if ("typedef".equals(this.getKind())) {
			if (type.indexOf("<") != -1) {
				String[] namespace = new String[] {};
				Tool.getAnonimousClass(parent, namespace, type, getTypeRef());
				TYPEDEFS.put(getName(), Tool.filterAnonimousString(type, getTypeRef()));
			} else {
				String[] split = getType().split(" ");
				String filterName = Tool.filterInvalidChar(split[split.length - 1]);
				if (getTypeRef() != null) {
					filterName = (getTypeRef().getValue() + " " + filterName).trim();
				}
				if (!"*".equals(filterName) 
						&& !"&".equals(filterName) 
						&& !"**".equals(filterName)
						&& !"".equals(filterName)) {
					TYPEDEFS.put(getName(), filterName);
				}
			}
		} else {
			System.out.println("NO DEAL(KIND)= " + this.getKind());
		}
		return parent;
	}

	protected void convertToEnum(IElement parent, File[] files)
			throws ProjectNotFoundException, ClassNotFoundException,
			InvalidEditingException, IOException, SAXException {
		IClass enumClass = Tool.getClass(((IClass) parent), getName());
		enumClass.addStereotype("enum");
		for (Iterator iterator = enumValues.iterator(); iterator.hasNext();) {
			EnumValue enumValue = (EnumValue) iterator.next();
			enumValue.convertToJudeModel(enumClass, files);
		}
		CompoundDef.compounddef.put(this.getId(), enumClass);
	}

	protected void convertToFunction(IElement parent, File[] files,
			BasicModelEditor basicModelEditor) throws InvalidEditingException,
			ClassNotFoundException, ProjectNotFoundException {
		String type = getTypeFromTypeDef(getType());
		type = dealWithConstForOperation(type);
		Object[] result = filterKeyword(type);
		Set keywords = (Set) result[0];
		type = ((String) result[1]).trim();
		String array = "";
		if (keywords.contains(KEYWORD_ARRAY)) {
			array = getType().substring(getType().indexOf("[")).trim();
		}
		if ("".equals(type) && typeRef != null) {
			type = typeRef.value.trim();
		}
		String filteredType = getTypeFromTypeDef(type).trim() + array;		
		IOperation fun = null;		
		if (LanguageManager.getCurrentLanguagePrimitiveType().contains(filteredType)) {
			fun = Tool.getOperation((IClass) parent, name, Tool.filterInvalidChar(filteredType));
		} else {
			String[] path;
			if (filteredType.indexOf("<") != -1) {
				path = new String[1];
				path[0] = filteredType;
			} else {
				path = filteredType.split("::");
			}
			filteredType = path.length > 0 ? path[path.length -1].trim() : filteredType.trim();
			String[] namespace = new String[] {};
			IClass classType = null;
			if (path.length > 1) {
				namespace = new String[path.length - 1];
				System.arraycopy(path, 0, namespace, 0, path.length - 1);
				classType = Tool.getClass(namespace, filteredType);
			}
			if (classType != null) {
				fun = Tool.getOperation((IClass) parent, name, classType);
			} else {
				if (filteredType.indexOf("<") != -1) {
					fun = createOperationWithAnonimousboundclass(parent, namespace, basicModelEditor, filteredType);
				}
				if (fun == null) {
					fun = Tool.getOperation((IClass) parent, name, Tool.filterInvalidChar(filteredType));
				}
			}
		}
		fun.setVisibility(this.getProt());
		fun.setStatic(!"no".equals(this.getStaticBoolean()));
		String definition = getDefinition();
		if (!"".equals(definition)) {
			fun.setDefinition(definition);
		}
		
		dealOperationKeyword(basicModelEditor, keywords, fun);
		
		int index = 0;
		for (Iterator iterator = memberParaList.iterator(); iterator.hasNext();) {
			Param param = (Param) iterator.next();
			IParameter iParameter = (IParameter) param.convertToJudeModel(fun, files);
			if (this.argsstring != null && param.declname == null) {
				String[] paramName = this.argsstring.split(",");
				dealParamName(iParameter, paramName[index]);
			}
			index++;
		}
	}

	private String dealWithConstForOperation(String type) {
		if (type.trim().indexOf(CONST) == 0) {
			type = type.replaceFirst(CONST, "").trim();
		}
		if (argsstring.indexOf(" " + CONST) != -1) {
			type = CONST + " " + type;
		}
		return type;
	}
	private void dealParamName(IParameter iParameter, String paramName)
			throws InvalidEditingException {
		dealCharacter(iParameter, paramName,"&");
		dealCharacter(iParameter, paramName,"*");
	}

	private void dealCharacter(IParameter iParameter, String paramName, String character)
			throws InvalidEditingException {
		if (paramName.indexOf(character) != -1 && !paramName.endsWith(character + ")")
				&& !paramName.endsWith(character)) {
			int indexOf = paramName.indexOf(character);
			if (paramName.endsWith(")")) {
				iParameter.setName(paramName.substring(indexOf + 1, paramName.length() - 1));
			} else {
				iParameter.setName(paramName.substring(indexOf + 1, paramName.length()));
			}
		}
	}
	
	private IOperation createOperationWithAnonimousboundclass(
			IElement parent, String[] allPath, BasicModelEditor basicModelEditor, String type) 
			throws ProjectNotFoundException,ClassNotFoundException, InvalidEditingException {
		Object[] result = filterKeyword(type);
		Set keywords = (Set) result[0];
		IClass anonimousClass = Tool.getAnonimousClass(allPath, null, type, getTypeRef());
		if (anonimousClass != null) {
			IOperation fun = Tool.getOperation((IClass) parent, name, anonimousClass);
			dealOperationKeyword(basicModelEditor, keywords, fun);
			return fun;
		}
		return null;
	}

	public static String getTypeFromTypeDef(String name) {
		String type = name;
		while ((type = (String) TYPEDEFS.get(type)) != null) {
			name = type;
		}
		return name;
	}

	protected void convertToAttribute(IElement parent,
			BasicModelEditor basicModelEditor) throws InvalidEditingException,
			ProjectNotFoundException, ClassNotFoundException, IOException {
		if (getType() != null && !"".equals(getType())) {
			createAttribute(parent, basicModelEditor);
		} else if(getTypeRef() != null) {
			//if is static, create attribute			
			IClass anotherCls = (IClass) CompoundDef.compounddef.get(getTypeRef().getRefid());
			if (!"no".equals(this.getStaticBoolean())
					|| Config.getClassNameAboutForbidCreateAssociation().contains(getIClassFullName(anotherCls))
					|| Config.getClassNameAboutForbidCreateAssociation().contains(getIClassFullName((IClass) parent))
					) {
				createAttribute(parent, basicModelEditor);
			} else {
				//if not, create association
				generateAssoication((IClass) parent, basicModelEditor, anotherCls);
			}
		}
	}
	
	private void createAttribute(IElement parent, BasicModelEditor basicModelEditor) 
	throws InvalidEditingException, ProjectNotFoundException, ClassNotFoundException {
		if (getType() != null && !"".equals(getType())) {
			Object[] result = filterKeyword(type);
			Set keywords = (Set) result[0];
			String type = ((String) result[1]).trim();
			if ("".equals(type) && typeRef != null) {
				type = typeRef.value;
			}
			String filteredType = getTypeFromTypeDef(type).trim();
			String[] typepaths;
			if (filteredType.indexOf("<") != -1) {
				typepaths = new String[1];
				typepaths[0] = filteredType;
			} else {
				typepaths = filteredType.split("::");
			}
			IAttribute attr = generateAttri(parent, basicModelEditor, typepaths);
			dealAttributeKeywords(basicModelEditor, keywords, attr);
		} else if (getTypeRef() != null) {
			IClass anotherCls = (IClass) CompoundDef.compounddef.get(getTypeRef().getRefid());
			generateAttri(parent, basicModelEditor,anotherCls);
		}
	}
	
	abstract void dealOperationKeyword(BasicModelEditor basicModelEditor,
			Set keywords, IOperation fun) throws InvalidEditingException;
	
	abstract void dealAttributeKeywords(BasicModelEditor basicModelEditor,
			Set keywords, IAttribute attr) throws InvalidEditingException;

	abstract Object[] filterKeyword(String type);

	void generateAttri(IElement parent,
			BasicModelEditor basicModelEditor,
			IClass type) throws InvalidEditingException,
			ProjectNotFoundException, ClassNotFoundException {
		IAttribute attr = Tool.getAttribute((IClass) parent, name, type);
		int [][]range = getMultiRange();
		if (range != null) {
			attr.setMultiplicity(range);
		}
		attr.setChangeable(!"no".equals(this.getConstBoolean()));
		attr.setVisibility(this.getProt());
		attr.setStatic(!"no".equals(this.getStaticBoolean()));
		String definition = getDefinition();		
		if (!"".equals(definition)) {
			attr.setDefinition(definition);
		}
		attr.setInitialValue(this.getInitializer());
	}
	
	IAttribute generateAttri(IElement parent,
			BasicModelEditor basicModelEditor,
			String[] path) throws InvalidEditingException,
			ProjectNotFoundException, ClassNotFoundException {		
		IAttribute attr = null;
		if (LanguageManager.getCurrentLanguagePrimitiveType().contains(path[0])) {
			attr = Tool.getAttribute((IClass) parent, name, path[0]);
		} else {
			String[] namespace = new String[] {};
			IClass classType = null;
			String type = path.length > 0 ? path[path.length -1].trim() : getType().trim();
			if (path.length > 1) {
				namespace = new String[path.length - 1];
				System.arraycopy(path, 0, namespace, 0, path.length - 1);
				classType = Tool.getClass(namespace, type);
			}
			if (classType != null) {
				attr = Tool.getAttribute((IClass) parent, name, classType);
			} else {
				if (type.indexOf("<") != -1) {				
					attr = createAttrWithAnonimousboundclass(parent, basicModelEditor, namespace, type);
				} else {
					type = Tool.filterInvalidChar(type);
				}
				if (attr == null) {
					IClass attType = Tool.getNestedClass((IClass) parent, type);
					if (attType == null) {
						attType = Tool.getClass(namespace, type);
					}
					attr = Tool.getAttribute((IClass) parent, name, attType);
				}
			}
		}
		if(!"property".equals(getKind())){
			int [][]range = getMultiRange();
			if (range != null) {
				attr.setMultiplicity(range);
			}
		}
		attr.setChangeable(!"no".equals(this.getConstBoolean()));
		attr.setVisibility(this.getProt());
		attr.setStatic(!"no".equals(this.getStaticBoolean()));
		String definition = getDefinition();		
		if (!"".equals(definition)) {
			attr.setDefinition(definition);
		}
		attr.setInitialValue(this.getInitializer());

		return attr;
	}

	private IAttribute createAttrWithAnonimousboundclass(
			IElement parent, BasicModelEditor basicModelEditor, String[] namespace, String type) 
			throws ProjectNotFoundException,ClassNotFoundException, InvalidEditingException {
		Object[] result = filterKeyword(type);
		Set keywords = (Set) result[0];
		IClass anonimousClass = Tool.getAnonimousClass(namespace, null, type, getTypeRef());
		if (anonimousClass != null) {
			IAttribute attr = Tool.getAttribute((IClass) parent, name, anonimousClass);
			dealAttributeKeywords(basicModelEditor, keywords, attr);
			return attr;
		}		
		return null;
	}

	void generateAssoication(IClass parent,
			BasicModelEditor basicModelEditor,
			IClass assocEnd) throws InvalidEditingException,
			ProjectNotFoundException, ClassNotFoundException {
		IAssociation attr = basicModelEditor.createAssociation(parent
				, assocEnd
				, name
				, ""
				, "");
		attr.setVisibility(this.getProt());
		String definition = getDefinition();
		if (!"".equals(definition)) {
			attr.setDefinition(definition);
		}
	}	
	
	int[][] getMultiRange() {
		StringBuffer buffer = new StringBuffer();
		int length = 0;
		String arrayString;
		if (type.indexOf("[") >= 0) {
			arrayString = type;
		} else if (this.argsstring.indexOf("[") >= 0) {
			arrayString = this.argsstring;
		} else {
			return null;
		}
		while (arrayString.indexOf("[") >= 0) {
			int beginIndex = arrayString.indexOf("[");
			int endIndex = arrayString.indexOf("]");
			if (endIndex - beginIndex >= 1) {
			buffer.append(arrayString.substring(beginIndex + 1, endIndex));
				buffer.append(" ,");
				length++ ;
			}
			arrayString = arrayString.substring(endIndex + 1);
		}		
		if (length == 0) {
			return null;
		}
		String[] mliti = buffer.toString().split(",");
		int[][] range = new int[length][1];
		for (int i = 0; i < length; i++) {
			int value = "".equals(mliti[i].trim()) ? -100 : Integer.valueOf(mliti[i].trim()).intValue();
			range[i][0] = value;
		}
		return range;		
	}
	
	private String getDefinition() {
		String definition = "";
		if (this.getBriefdescriptionPara() != null) {
			definition += "\\brief ";
			definition += getBriefdescriptionPara();
		}
		if(this.getDetaileddescriptionPara()!= null){
			definition += this.getDetaileddescriptionPara().trim();	
		}
		return definition;
	}

}