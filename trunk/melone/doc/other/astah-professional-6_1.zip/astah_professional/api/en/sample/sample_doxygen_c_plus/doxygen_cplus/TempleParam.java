package doxygen_cplus;
import java.io.File;

import com.change_vision.jude.api.inf.editor.BasicModelEditor;
import com.change_vision.jude.api.inf.editor.ModelEditorFactory;
import com.change_vision.jude.api.inf.exception.InvalidEditingException;
import com.change_vision.jude.api.inf.exception.ProjectNotFoundException;
import com.change_vision.jude.api.inf.model.IClass;
import com.change_vision.jude.api.inf.model.IElement;

/**
 * this class extend Param
 *  the sub-tag is <defval>.it is named "defval"
 */
public class TempleParam extends Param {
	private String defval;

	public String getDefval() {
		return defval;
	}

	public void setDefval(String defval) {
		this.defval = defval;
	}
	
	public IElement convertToJudeModel(IElement parent, File[] files) throws InvalidEditingException,
			ClassNotFoundException, ProjectNotFoundException {
		String paramName = null;
		BasicModelEditor basicModelEditor = ModelEditorFactory.getBasicModelEditor();
		if (declname != null) {
			paramName = declname;
		}
		if (defname != null) {
			paramName = defname;
		}
		
		String[] result = type.split(" ");
		if (paramName != null) {
			if ("class".equals(result[0])) {
				basicModelEditor.createTemplateParameter(((IClass) parent), paramName, (IClass) null, defval);
			} else {
				basicModelEditor.createTemplateParameter(((IClass) parent), paramName, type, defval);
			}
		} else {
			if ("class".equals(result[0])) {
				paramName = result[result.length - 1];
				basicModelEditor.createTemplateParameter(((IClass) parent), paramName, (IClass) null, defval);
			}
		}
		return parent;
	}
}
