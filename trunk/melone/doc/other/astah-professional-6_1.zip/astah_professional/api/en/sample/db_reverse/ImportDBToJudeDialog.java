import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.MalformedURLException;
import java.sql.SQLException;
import java.util.List;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.filechooser.FileFilter;

import com.change_vision.jude.api.inf.exception.InvalidEditingException;
import com.change_vision.jude.api.inf.exception.LicenseNotFoundException;
import com.change_vision.jude.api.inf.exception.ProjectLockedException;

public class ImportDBToJudeDialog extends JFrame implements ActionListener {
	
	public static final String ORACLE = "Oracle";
	
	public static final String MYSQL = "MySQL";
	
	public static final String MSSQLSERVER = "MS SQLServer";
	
	public static final String POSTGRES = "PostgreSQL";

	public static final String HSQL = "HSQLDB";
	
	public static final String H2 = "H2 Database Engine";
	
	public static final String HiRDB = "HiRDB";
	
	public static final String OTHERS_SCHEMA = "Others[set schema]";
	
	public static final String OTHERS_CATEGORY = "Others[set category]";
	
	private JComboBox urlCombo = null;
	
	private JTextField userField = null;
	
	private JPasswordField pswField = null;
	
	private JTextField driverField = null;
	
	private JTextField jdbcField = null;
	
	private JTextArea messageArea = null;
	
	private JTextField targetModelField = null;
	
	private JButton selectDriverBtn = null;
	
	private JButton selectProjectBtn = null;
	
	private JButton connectBtn = null;
	
	private JButton importBtn = null;
	
	private JButton closeBtn = null;
	
	private JButton clearBtn = null;
	
	private JComboBox dbCombo = null;
	
	private JComboBox schemaCombo = null;
	
	private DBReader dbReader = null;
	
	private DBProperties properties = null;
	
	private Preferences prefs = null;
	
	public ImportDBToJudeDialog() {
		super();
		
		prefs = Preferences.userNodeForPackage(this.getClass());		
		properties = new DBProperties();
		
		Container contentPane = getContentPane();
		setTitle("Astah DB Reverse Tool");
		
		JPanel connectPanel = createConnectPanel();
		contentPane.add(connectPanel, BorderLayout.NORTH);
		
		JPanel importPanel = createImportPanel();
		contentPane.add(importPanel, BorderLayout.CENTER);
		
		JPanel buttonPanel = createButtonPanel();
		contentPane.add(buttonPanel, BorderLayout.SOUTH);
		
        setSize(600, 440);		
        setLocation();
        setResizable(false);
        showMessage("Please press Connect button to connect DB.");
	}
	
	private void setLocation() {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension frameSize = getSize(); 
		if (frameSize.height > screenSize.height)  
		    frameSize.height = screenSize.height;         
		if (frameSize.width > screenSize.width)  
		  frameSize.width = screenSize.width;         
		setLocation((screenSize.width-frameSize.width) / 2, (screenSize.height-frameSize.height) / 2);
	}
	
	private JPanel createConnectPanel() {
		CommonGridBagLayout layout = new CommonGridBagLayout();
		JPanel connectPanel = new JPanel(layout);
		//DB
		dbCombo = new JComboBox();
		dbCombo.setEditable(false);
		addItems(dbCombo);
		dbCombo.setSelectedItem(prefs.get(DBProperties.CURRENT_DB, ""));
		dbCombo.addActionListener(this);
		addLine(connectPanel, layout, dbCombo, "Connect using:");
		
		//URL
		urlCombo = new JComboBox();
		urlCombo.setEditable(true);
		String oldUrl = prefs.get(DBProperties.URL, "");
		initURLComboBox(oldUrl);
		if (null != oldUrl && !"".equals(oldUrl)) {			
			urlCombo.setSelectedItem(oldUrl);
		} else {
			String oracle = properties.getURL(ORACLE);
			urlCombo.setSelectedItem(oracle);
		}
		urlCombo.addActionListener(this);
		addLine(connectPanel, layout, urlCombo, "URL:");
		
		//User
		userField = new JTextField();
		String oldUser = prefs.get(DBProperties.USER, "");
		if (null != oldUser && !"".equals(oldUser)) {
			userField.setText(oldUser);
		} else {
			userField.setText(properties.getUser(ORACLE));
		}
		addLine(connectPanel, layout, userField, "User:");		

		//Password
		pswField = new JPasswordField();
		addLine(connectPanel, layout, pswField, "Password:");
		
		//Driver
		driverField = new JTextField();
		String oldDriver = prefs.get(DBProperties.JDBC_DRIVER, "");
		if (null != oldDriver && !"".equals(oldDriver)) {
			driverField.setText(oldDriver);
		} else {
			driverField.setText(properties.getJDBCDriver(ORACLE));
		}
		addLine(connectPanel, layout, driverField, "JDBC Driver:");
				
		//Path of Driver (jar)
		jdbcField = new JTextField();
		String oldPath = prefs.get(DBProperties.DRIVER_PATH, "");
		if (null != oldPath) {
			jdbcField.setText(oldPath);
		} else {
			jdbcField.setText(properties.getDriverPath(ORACLE));
		}
		selectDriverBtn = new JButton("Select");
		selectDriverBtn.addActionListener(this);
		addLineWithButton(connectPanel, layout, jdbcField, "Driver path:", selectDriverBtn);
		
		//Connect
		schemaCombo = new JComboBox();
		schemaCombo.setEditable(false);
		schemaCombo.setEnabled(false);		
		addLine(connectPanel, layout, schemaCombo, "Schemas:");
		
		clearBtn = new JButton("Clear");
		clearBtn.addActionListener(this);
		addLineWithButton(connectPanel, layout, new JLabel(), "Console:", clearBtn);
		
		return connectPanel;
	}
	
	private void initURLComboBox(String oldUrl) {
		urlCombo.removeAllItems();
		String type = dbCombo.getSelectedItem().toString();
		String jdbcUrl = properties.getURL(type);
		urlCombo.addItem(oldUrl);
		if (isJdbcOdbcUrl(oldUrl)) {
			urlCombo.addItem(jdbcUrl);
		} else {
			urlCombo.addItem("jdbc:odbc:dataSoureceName");
		}
	}
	
	private boolean isJdbcOdbcUrl(String url) {
		return url != null
		&& url.length() >= 10
		&& url.substring(0,10).equalsIgnoreCase("jdbc:odbc:");
	}
	
	private JPanel createImportPanel() {	
		JPanel importContent = new JPanel(new BorderLayout());
		
		//Message Area
		messageArea = new JTextArea();
		messageArea.setEditable(false);
		messageArea.setAutoscrolls(true);
		messageArea.setLineWrap(true);
		messageArea.setWrapStyleWord(true);
		messageArea.setRows(6);
		messageArea.setBorder(BorderFactory.createLineBorder(Color.black));
		JScrollPane scroll = new JScrollPane(messageArea);
		importContent.add(scroll, BorderLayout.CENTER);
		
		CommonGridBagLayout layout = new CommonGridBagLayout();
		JPanel importPanel = new JPanel(layout);
		
		//Target model
		targetModelField = new JTextField();
		targetModelField.setText(prefs.get(DBProperties.TARGET_MODEL, ""));
		selectProjectBtn = new JButton("Select");
		selectProjectBtn.addActionListener(this);
		addLineWithButton(importPanel, layout, targetModelField, "Target model:", selectProjectBtn);
		importContent.add(importPanel, BorderLayout.SOUTH);
		
		return importContent;
	}
	
	private JPanel createButtonPanel() {
		//Button Import and Close
		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		
		connectBtn = new JButton("Connect");
		connectBtn.addActionListener(this);
		buttonPanel.add(connectBtn);
		
		importBtn = new JButton("Import");
		importBtn.addActionListener(this);
		importBtn.setEnabled(false);
		buttonPanel.add(importBtn);
		
		closeBtn = new JButton("Close");
		closeBtn.addActionListener(this);
		buttonPanel.add(closeBtn);
		
		return buttonPanel;
	}
	
	private void addLine(JPanel parentPanel, CommonGridBagLayout layout,
			JComponent component, String label) {
		JLabel jLabel = new JLabel("");
		layout.setLayout(jLabel, 1, 1, false);
		parentPanel.add(jLabel);
		
		JLabel url = new JLabel(label);
		layout.setLayout(url, 1, 1, false);
		parentPanel.add(url);
		
		layout.setLayout(component, 1, 6, true);
		parentPanel.add(component);
	}
	
	private void addLineWithButton(JPanel parentPanel, CommonGridBagLayout layout,
			JComponent component, String label, JButton button) {
		JLabel jLabel = new JLabel("");
		layout.setLayout(jLabel, 1, 1, false);
		parentPanel.add(jLabel);
		
		JLabel jdbc = new JLabel(label);
		layout.setLayout(jdbc, 1, 1, false);
		parentPanel.add(jdbc);

		layout.setLayout(component, 1, 30, false);
		parentPanel.add(component);

		layout.setLayout(button, 1, 1, false);		
		parentPanel.add(button);
		
		jLabel = new JLabel("");
		layout.setLayout(jLabel, 1, 1, true);
		parentPanel.add(jLabel);
	}
	
	private void addItems(JComboBox box) {
		String[] DBs = properties.getDBTypes();
		for (int i = 0; i < DBs.length; i++) {
			box.addItem(DBs[i].trim());
		}
	}

	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if (obj == dbCombo) {
			updateConntectInfo(null);
			if(!shouldDBConnected()) {
				disconnectDB();
			}
		} else if (obj == urlCombo) {
			if (urlCombo.getSelectedItem() != null) {
				String url = urlCombo.getSelectedItem().toString();
				updateConntectInfo(url);
			}			
		} else if (obj == selectDriverBtn) {
            selectDriver();
		} else if (obj == connectBtn) {
			if (shouldDBConnected()) {
				connect();
				saveConnectInfo();	
			} else {
				disconnectDB();
			}
		} else if (obj == selectProjectBtn) {
			selectProject();
		} else if (obj == importBtn) {
			importToJude();
			saveImportFilePath();
		} else if (obj == closeBtn) {
			try {				
				close();
			} catch (SQLException e1) {
				dbReader = null;
				showErrorMessage(e1);
			}
		} else if (obj == clearBtn) {
			messageArea.setText("");
		}
	}
	
	private void updateConntectInfo(String url) {
		String dbType = dbCombo.getSelectedItem().toString();
		if (dbType.equals(prefs.get(DBProperties.CURRENT_DB, ""))
				&& (url == null || url.equals(prefs.get(DBProperties.URL, "")))) {
			String oldUrl = prefs.get(DBProperties.URL, "");
			initURLComboBox(oldUrl);
			urlCombo.setSelectedItem(prefs.get(DBProperties.URL, ""));
			userField.setText(prefs.get(DBProperties.USER, ""));			
			driverField.setText(prefs.get(DBProperties.JDBC_DRIVER, ""));
			jdbcField.setText(prefs.get(DBProperties.DRIVER_PATH, ""));
		} else {
			if (url == null) {
				url = properties.getURL(dbType);
				initURLComboBox(url);
				urlCombo.setSelectedItem(url);
			}
			if (isJdbcOdbcUrl(url)) {
				userField.setText(properties.getUser(dbType));			
				driverField.setText("sun.jdbc.odbc.JdbcOdbcDriver");
				jdbcField.setText("");
			} else {
				userField.setText(properties.getUser(dbType));			
				driverField.setText(properties.getJDBCDriver(dbType));
				jdbcField.setText(properties.getDriverPath(dbType));
			}			
		}
		pswField.setText("");
	}

	private boolean shouldDBConnected() {
		return "Connect".equals(connectBtn.getText());
	}

	private void disconnectDB() {
		closeReader();
		connectBtn.setText("Connect");
		
		urlCombo.setEnabled(true);
		userField.setEditable(true);		
		pswField.setEditable(true);
		driverField.setEditable(true);
		selectDriverBtn.setEnabled(true);
		jdbcField.setEditable(true);
		schemaCombo.removeAllItems();
		schemaCombo.setEnabled(false);
		
		importBtn.setEnabled(false);
	}
	
	private void saveConnectInfo() {
		String dbType = dbCombo.getSelectedItem().toString();
		try {
			prefs.put(DBProperties.CURRENT_DB, dbType);
			prefs.put(DBProperties.URL, urlCombo.getSelectedItem().toString());
			prefs.put(DBProperties.USER, userField.getText());
			prefs.put(DBProperties.JDBC_DRIVER, driverField.getText());
			prefs.put(DBProperties.DRIVER_PATH, jdbcField.getText());		
			prefs.flush();
		} catch (BackingStoreException e) {
			e.printStackTrace();
		}
	}
	
	private void saveImportFilePath() {
		try {
			prefs.put(DBProperties.TARGET_MODEL, targetModelField.getText());		
			prefs.flush();
		} catch (BackingStoreException e) {
			e.printStackTrace();
		}
	}

	private void close() throws SQLException {
		closeReader();
		dispose();
	}
	
	private void closeReader() {
		if (dbReader != null) {
			try {
				dbReader.close();
			} catch (SQLException e) {
				showErrorMessage(e);
			}
			dbReader = null;
			showMessage("Connection Closed.");
		}
	}

	private void selectProject() {
		JFileChooser fileChooser = getFileChooser(new String[] {".asta", ".jude"}, "Project File");
        if (fileChooser.showSaveDialog(getGlassPane()) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = fileChooser.getSelectedFile();
		if (file == null) {
			return;
		}

		String fileName = file.getAbsolutePath();

		if (!fileName.toLowerCase().endsWith(".asta")
				&& !fileName.toLowerCase().endsWith(".jude")) {
			fileName += ".asta";
		}
		targetModelField.setText(fileName);
	}

	private void importToJude() {
		if (dbReader == null) {
			showMessage("Database is not connected!");
			return;
		}		
		String judePath = targetModelField.getText();
		if ("".equals(judePath)) {
			showMessage("Please select a path first");
			return;
		}
		
		if (!isOverWrite(judePath)) {
			return;
		}		
		showMessage("Importing...");
		go();		
	}
	
	public void go() {
        final Thread worker = new Thread() {
            public void run() {            	
            	startImport();
            }
        };
        worker.start();
    }
	
	private void startImport() {
		String dbName = null;
		Object item = schemaCombo.getSelectedItem();
		if (item != null) {
			dbName = item.toString();
		}		
		String judePath = targetModelField.getText();
		try {
			String currentDBType = dbCombo.getSelectedItem().toString();
			List tables = null;
			List relationships = null;
			if (MYSQL.equalsIgnoreCase(currentDBType)
					|| MSSQLSERVER.equalsIgnoreCase(currentDBType)
					|| OTHERS_CATEGORY.equalsIgnoreCase(currentDBType)) {
				tables = dbReader.getTables(dbName, null);
				relationships = dbReader.getRelationships(dbName, null);
			} else {
				tables = dbReader.getTables(null, dbName);
				relationships = dbReader.getRelationships(null, dbName);
			}
			DBToJude dbtj = new DBToJude() {
				public void showTableCount(int count) {
					showMessage("The number of imported tables:" + count);
				}
				
				public void showImportingTable(String tableName) {
					showMessage("Imported table:" + tableName);
				}
			};
			dbtj.importToJude(judePath, tables, relationships);			
			showMessage("Import Successfully");
		} catch (LicenseNotFoundException e) {
			showErrorMessage(e);
		} catch (ProjectLockedException e) {
			showErrorMessage(e);
		} catch(InvalidEditingException e) {
			showErrorMessage(e);
		} catch (Throwable e) {			
			showErrorMessage(e);
		}
	}
	
	private void connect() {
		schemaCombo.removeAllItems();
		dbReader = new DBReader();
		String dbType = dbCombo.getSelectedItem().toString();
		if (ORACLE.equalsIgnoreCase(dbType)) {
			dbReader.setDBType(DBReader.ORACLE);
		} else if (MYSQL.equalsIgnoreCase(dbType)) {
			dbReader.setDBType(DBReader.MYSQL);			
		} else if (MSSQLSERVER.equalsIgnoreCase(dbType)) {
			dbReader.setDBType(DBReader.MSSQLSERVER);
		} else if (POSTGRES.equalsIgnoreCase(dbType)) {
			dbReader.setDBType(DBReader.POSTGRES);
		} else if (HSQL.equalsIgnoreCase(dbType)) {
			dbReader.setDBType(DBReader.HSQL);
		} else if (H2.equalsIgnoreCase(dbType)) {
			dbReader.setDBType(DBReader.H2);
		} else if (HiRDB.equalsIgnoreCase(dbType)) {
			dbReader.setDBType(DBReader.HiRDB);
		} else {
			dbReader.setDBType(dbType);
		}
		
		ConnectionInfo diverInfo = new ConnectionInfo();
		diverInfo.setClassname(driverField.getText());
		diverInfo.setPathfile(jdbcField.getText());
		
		diverInfo.setLogin(userField.getText());
		diverInfo.setPassword(String.copyValueOf(pswField.getPassword()));
		diverInfo.setJdbcurl(urlCombo.getSelectedItem().toString());
		
		try {			
			dbReader.connect(diverInfo);
			importBtn.setEnabled(true);
			schemaCombo.setEnabled(true);
			String[] schemas = dbReader.getSchemas();
			for (int i = 0; i < schemas.length; i++) {
				schemaCombo.addItem(schemas[i]);
				if (urlCombo.getSelectedItem().toString().toLowerCase().endsWith(((String) schemas[i]).toLowerCase())) {
					schemaCombo.setSelectedItem(schemas[i]);
				}
			}
			showMessage("Connection Succeeded.");
			showMessage("Please choose a schema for importing DB by Schemas item before DB import is started.");
			showMessage("Please press Import button to import DB or press Disconnect button to disable connection.");
			
			postConnect();
			
		} catch (MalformedURLException e) {
			dbReader = null;
			showErrorMessage(e);
		} catch (SQLException e) {
			e.printStackTrace();
			dbReader = null;
			showErrorMessage(e);
		} catch (InstantiationException e) {
			dbReader = null;
			showErrorMessage(e);
		} catch (IllegalAccessException e) {
			dbReader = null;
			showErrorMessage(e);
		} catch (ClassNotFoundException e) {
			dbReader = null;
			showErrorMessage(e);
		}		
	}
	
	private void postConnect() {
		connectBtn.setText("Disconnect");
		
		urlCombo.setEnabled(false);
		userField.setEditable(false);		
		pswField.setEditable(false);
		driverField.setEditable(false);
		selectDriverBtn.setEnabled(false);
		jdbcField.setEditable(false);
	}

	public void showMessage(String message) {
		if (!message.endsWith("\n")) {
			messageArea.append(message + "\n");
		} else {
			messageArea.append(message);
		}
	}
	private void showErrorMessage(Throwable e) {
		if (e instanceof InvalidEditingException) {
			InvalidEditingException exception = (InvalidEditingException) e;
			messageArea.append(exception.getKey() + " : " + exception.getMessage() + "\n");
		} else {
			messageArea.append(e.toString() + "\n");
		}
	}
	
	private boolean isOverWrite(String fileName) {
		// confirm overwrite
	    File file = new File(fileName);
	    if (file.exists()) {
	        int n = showYesNoDialog("Do you want to overwrite the existing file?");
	        if (n == JOptionPane.YES_OPTION) {
	            return true;
	        } else {
	            return false;
	        }
	    }
	    return true;
	}
	
	private int showYesNoDialog(String message) {        
        return JOptionPane.showConfirmDialog(
        		getGlassPane(), 
        		message, 
        		"Confirm", 
        		JOptionPane.YES_NO_OPTION);
	}
	
	private void selectDriver() {
		JFileChooser fileChooser = getFileChooser(new String[] {".jar"}, "jdbc Driver");
        if (fileChooser.showOpenDialog(getGlassPane()) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = fileChooser.getSelectedFile();
		if (file == null) {
			return;
		}

		String fileName = file.getAbsolutePath();

		jdbcField.setText(fileName);
	}
	
	private JFileChooser getFileChooser(String[] extentions, String description) {
		JFileChooser fileChooser = new JFileChooser(targetModelField.getText());
		
		FileFilter filter = new CommonFilter(extentions, description);
		fileChooser.addChoosableFileFilter(filter);
		fileChooser.setFileFilter(filter);
		
		return fileChooser;
	}
	
	private class CommonGridBagLayout extends GridBagLayout {

	    private GridBagConstraints constraint = null;
	    private int column;
	    private int line;

	    public CommonGridBagLayout() {
	        super();
	        constraint = new GridBagConstraints();
	        constraint.gridheight = 1;
	        constraint.fill = GridBagConstraints.BOTH;
	        column = 0;
	        line = 0;
	    }
	    
	    public void setLayout(JComponent component, int width, double weightx, boolean lineFeed) {
	        constraint.gridwidth = width;
	        constraint.gridx = column;
	        constraint.gridy = line;
	        // when width == 1, if there is more room, cell use little room.
	        constraint.weightx = weightx;
	        
	        setConstraints(component, constraint);

	        column += width;
	        if (lineFeed) {
	            line++;
	            column = 0;
	        }
	    }
	}
	
	private class CommonFilter  extends FileFilter {
		private String[] extentions;		
		private String description;
		
		public CommonFilter (String[] extentions, String description) {
			this.extentions = extentions;
			this.description = description;
		}
		
		public boolean accept(File f) {
			if (f.isDirectory()) {
				return true;
			}
			for (String ext : extentions) {
				if (f.getName().endsWith(ext)) {
					return true;
				}
			}
	        return false;
		}

		public String getDescription() {
			String fullDescription = description == null ? "(" : description + " (";
			for (int i = 0; i < extentions.length; i++) {
				String ext = extentions[i];
				if (i == 0 && !ext.startsWith(".")) {
					fullDescription += ".";
				}
				fullDescription += ext;
				if (i != extentions.length - 1) {
					fullDescription += ", ";
				}
			}
			fullDescription += ")";
			return fullDescription;
		}		
	}
	
	public static void main(String[] args) {
		ImportDBToJudeDialog dialog = new ImportDBToJudeDialog();
		dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		dialog.setVisible(true);
	}
}
