package doxygen_cplus;


public class TempleParamCPlus extends TempleParam {
}