
 Sweetie BasePack 
 ----------------

 Author:  Joseph North
 Email:   sublick@gmail.com
 Licence: Attribution-ShareAlike 3.0
 Website: sweetie.sublink.ca


 Updates
 ----------------

 2007-03: Restyled all icons
          Changed unlocked icons
          Changed check icons
          Added bullet several icons

 2006-10: Cleaned up member icons

 2006-04: Added 47 more icons
          Cleaned up several icons

 2005-xx: First release


 Information
 ----------------

 A set of clean icons for use in web applications
 or program interfaces.

 New and updated icons can be found on the Sweetie
 project page at http://sweetie.sublink.ca/

 Feel free to email me with any comments you have. I'd love to hear
 what kind of uses my icons are serving.


 File Formats
 ----------------

 png-24   24-bit PNG format (alpha-blending transparency)

          These icons blend with dark and light backgrounds
          but do not work in Internet Explorer 6


 png-8    8-bit PNG format (single-bit transparency)
          
          Use these if you can't use the 24-bit versions


 psd      Adobe Photoshop Document format

          Use these to easily change any of the icons