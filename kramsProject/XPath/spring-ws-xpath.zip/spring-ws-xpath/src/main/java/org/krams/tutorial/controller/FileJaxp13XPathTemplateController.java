package org.krams.tutorial.controller;

import java.io.InputStream;
import java.util.HashMap;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.krams.tutorial.oxm.SubscriptionResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.xml.xpath.Jaxp13XPathTemplate;
import org.springframework.xml.xpath.NodeMapper;
import org.springframework.xml.xpath.XPathOperations;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * Controller for handling XPathTemplate requests
 */
@Controller
@RequestMapping("/file/jaxp13xpathtemplate")
public class FileJaxp13XPathTemplateController {

	protected static Logger logger = Logger.getLogger("controller");

    private XPathOperations template = new Jaxp13XPathTemplate();

    @RequestMapping(method = RequestMethod.GET)
    public String getResults(final Model model) {
    	logger.debug("Received request to show demo page");

    	// Load the XML document
		InputStream reportStream = this.getClass().getResourceAsStream("/sample.xml"); 
		StreamSource source = new StreamSource( reportStream );
		   
		// Set the namespace; otherwise we won't find our items
		HashMap<String, String> namespaces = new HashMap<String, String>();
		namespaces.put("SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/");
		namespaces.put("base", "http://krams915.blogspot.com/ws/schema/oss");
		((Jaxp13XPathTemplate) template).setNamespaces(namespaces);
		
		logger.debug("Evaluating expression");
        SubscriptionResponse response = template.evaluateAsObject("//SOAP-ENV:Envelope//base:subscriptionResponse", source, new NodeMapper<SubscriptionResponse>() {
            public SubscriptionResponse mapNode(Node node, int nodeNum) throws DOMException {
            	Element element = (Element) node;
                // Retrieve code element
                Element code = (Element) element.getChildNodes().item(1);
                // Retrieve description element
                Element description = (Element) element.getChildNodes().item(3);
               
                //Map XML values to our custom Object
                SubscriptionResponse response = new SubscriptionResponse();
                response.setCode(code.getTextContent());
                response.setDescription(description.getTextContent());
                
                // Retrieve local name and attribute values for demonstration purposes
                logger.debug(code.getLocalName());
                logger.debug(code.getAttribute("id"));
                logger.debug(description.getLocalName());
                logger.debug(description.getAttribute("type"));
                
                // Add to model
                model.addAttribute("namespaceURI", element.getNamespaceURI());
                model.addAttribute("nodeType", element.getNodeType());
                model.addAttribute("nodeName", element.getNodeName());
                model.addAttribute("parentNode", element.getParentNode());
                model.addAttribute("prefix", element.getPrefix());
                model.addAttribute("nextSibling", element.getNextSibling());
                model.addAttribute("textContent", element.getTextContent());
                
                return response;
            }
        });
        
        // Add mapped object to model
        model.addAttribute("response", response);

        // Add type description to model
        model.addAttribute("type", "Jaxp13XPathTemplate from a File source");
        
    	// This will resolve to /WEB-INF/jsp/xpathresultpage.jsp
    	return "xpathresultpage";
	}
    
}
