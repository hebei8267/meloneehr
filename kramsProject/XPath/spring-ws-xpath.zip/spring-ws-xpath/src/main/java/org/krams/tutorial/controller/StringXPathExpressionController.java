package org.krams.tutorial.controller;

import java.io.StringReader;

import javax.annotation.Resource;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.log4j.Logger;
import org.krams.tutorial.oxm.SubscriptionResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.xml.xpath.NodeMapper;
import org.springframework.xml.xpath.XPathExpression;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

/**
 * Controller for handling XPathExpression requests
 */
@Controller
@RequestMapping("/string/xpathexpression")
public class StringXPathExpressionController {

	protected static Logger logger = Logger.getLogger("controller");
    
	// Loads an XPathExpression from the xpath-context.xml
    @Resource(name="xpathExpression")
    private XPathExpression xpathExpression;

    @RequestMapping(method = RequestMethod.GET)
    public String getResults(final Model model) {
    	logger.debug("Received request to show demo page");
        
    	// Defines a factory API that enables applications to obtain a parser that 
    	// produces DOM object trees from XML documents. 
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        
        // Enable namespaces because our XML uses namespaces
        factory.setNamespaceAware(true); 
        
        // The Document interface represents the entire HTML or XML document. 
        // Conceptually, it is the root of the document tree, and provides the primary 
        // access to the document's data. 
        Document doc = null;
        
		try {
			// Load a String XML
			InputSource source = new InputSource( new StringReader(getStringXML()) );

			// Parse the XML file as an input source
			doc = factory.newDocumentBuilder().parse(source);
	
		} catch (Exception e) {
			logger.error(e);
		} 
		
		logger.debug("Retrieving primary node");
        Node nodeSource = doc.getDocumentElement();

        logger.debug("Evaluating XPathExpression");
        SubscriptionResponse response = xpathExpression.evaluateAsObject(nodeSource,
        		new NodeMapper<SubscriptionResponse>() {
		            public SubscriptionResponse mapNode(Node node, int nodeNum) throws DOMException {
		            	Element element = (Element) node;
		                // Retrieve code element
		                Element code = (Element) element.getChildNodes().item(1);
		                // Retrieve description element
		                Element description = (Element) element.getChildNodes().item(3);
		               
		                //Map XML values to our custom Object
		                SubscriptionResponse response = new SubscriptionResponse();
		                response.setCode(code.getTextContent());
		                response.setDescription(description.getTextContent());
		                
		                // Retrieve local name and attribute values for demonstration purposes
		                logger.debug(code.getLocalName());
		                logger.debug(code.getAttribute("id"));
		                logger.debug(description.getLocalName());
		                logger.debug(description.getAttribute("type"));
		                
		                // Add to model
		                model.addAttribute("namespaceURI", element.getNamespaceURI());
		                model.addAttribute("nodeType", element.getNodeType());
		                model.addAttribute("nodeName", element.getNodeName());
		                model.addAttribute("parentNode", element.getParentNode());
		                model.addAttribute("prefix", element.getPrefix());
		                model.addAttribute("nextSibling", element.getNextSibling());
		                model.addAttribute("textContent", element.getTextContent());
		                
		                return response;
		            }
        		});
        

        // Add mapped object to model
        model.addAttribute("response", response);
        
        // Add type description to model
        model.addAttribute("type", "XPathExpression from a String source");
        
    	// This will resolve to /WEB-INF/jsp/xpathresultpage.jsp
    	return "xpathresultpage";
	}
    
    public String getStringXML() {
    	
    	String xml = ""
        	+ "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">"
        	+ "	<SOAP-ENV:Header>"
        	+ "		<wsse:Security xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" SOAP-ENV:mustUnderstand=\"1\">"
        	+ "			<wsu:Timestamp xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\" wsu:Id=\"XWSSGID-1294933019426-1489568038\">"
        	+ "				<wsu:Created>2011-01-13T15:42:00.516Z</wsu:Created>"
        	+ "				<wsu:Expires>2011-01-13T15:47:00.516Z</wsu:Expires>"
        	+ "			</wsu:Timestamp>"
        	+ "			<wsse:UsernameToken xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\" wsu:Id=\"XWSSGID-12949330194261896507786\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">"
        	+ "				<wsse:Username>mojo</wsse:Username>"
        	+ "				<wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest\">ZalI6+DTAFvlYM2h4DBg56rpyhY=</wsse:Password>"
        	+ "				<wsse:Nonce EncodingType=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary\">smqvjzTKmKJkQlrSCubs/ZSm</wsse:Nonce>"
        	+ "				<wsu:Created xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">2011-01-13T15:42:00.521Z</wsu:Created>"
        	+ "			</wsse:UsernameToken>"
        	+ "		</wsse:Security>"
        	+ "	</SOAP-ENV:Header>"
        	+ "	<SOAP-ENV:Body>"
        	+ "		<subscriptionResponse xmlns=\"http://krams915.blogspot.com/ws/schema/oss\">"
        	+ "			<code id=\"200\">SUCCESS</code>"
        	+ "			<description type=\"plain\">User has been subscribed</description>"
        	+ "		</subscriptionResponse>"
        	+ "	</SOAP-ENV:Body>"
        	+ "</SOAP-ENV:Envelope>";
    	
    	return xml;
    }
}
