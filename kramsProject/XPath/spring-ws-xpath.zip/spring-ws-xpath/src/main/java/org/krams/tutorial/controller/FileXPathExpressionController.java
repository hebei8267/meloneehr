package org.krams.tutorial.controller;

import java.io.InputStream;
import javax.annotation.Resource;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.log4j.Logger;
import org.krams.tutorial.oxm.SubscriptionResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.xml.xpath.NodeMapper;
import org.springframework.xml.xpath.XPathExpression;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * Controller for handling XPathExpression requests
 */
@Controller
@RequestMapping("/file/xpathexpression")
public class FileXPathExpressionController {

	protected static Logger logger = Logger.getLogger("controller");
    
	// Loads an XPathExpression from the xpath-context.xml
    @Resource(name="xpathExpression")
    private XPathExpression xpathExpression;

    @RequestMapping(method = RequestMethod.GET)
    public String getResults(final Model model) {
    	logger.debug("Received request to show demo page");
        
    	// Defines a factory API that enables applications to obtain a parser that 
    	// produces DOM object trees from XML documents. 
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        
        // Enable namespaces because our XML uses namespaces
        factory.setNamespaceAware(true); 
        
        // The Document interface represents the entire HTML or XML document. 
        // Conceptually, it is the root of the document tree, and provides the primary 
        // access to the document's data. 
        Document doc = null;
        
		try {
			// Load an external XML file
			InputStream source = this.getClass().getResourceAsStream("/sample.xml"); 

			// Parse the XML file as an input stream
			doc = factory.newDocumentBuilder().parse(source);
	
		} catch (Exception e) {
			logger.error(e);
		} 
		
		logger.debug("Retrieving primary node");
        Node nodeSource = doc.getDocumentElement();

        logger.debug("Evaluating XPathExpression");
        SubscriptionResponse response = xpathExpression.evaluateAsObject(nodeSource,
        		new NodeMapper<SubscriptionResponse>() {
		            public SubscriptionResponse mapNode(Node node, int nodeNum) throws DOMException {
		                Element element = (Element) node;
		                // Retrieve code element
		                Element code = (Element) element.getChildNodes().item(1);
		                // Retrieve description element
		                Element description = (Element) element.getChildNodes().item(3);
		               
		                //Map XML values to our custom Object
		                SubscriptionResponse response = new SubscriptionResponse();
		                response.setCode(code.getTextContent());
		                response.setDescription(description.getTextContent());
		                
		                // Retrieve local name and attribute values for demonstration purposes
		                logger.debug(code.getLocalName());
		                logger.debug(code.getAttribute("id"));
		                logger.debug(description.getLocalName());
		                logger.debug(description.getAttribute("type"));
		                
		                // Add to model
		                model.addAttribute("namespaceURI", element.getNamespaceURI());
		                model.addAttribute("nodeType", element.getNodeType());
		                model.addAttribute("nodeName", element.getNodeName());
		                model.addAttribute("parentNode", element.getParentNode());
		                model.addAttribute("prefix", element.getPrefix());
		                model.addAttribute("nextSibling", element.getNextSibling());
		                model.addAttribute("textContent", element.getTextContent());
		                
		                return response;
		            }
        		});
        

        // Add mapped object to model
        model.addAttribute("response", response);

        // Add type description to model
        model.addAttribute("type", "XPathExpression from a File source");
        
    	// This will resolve to /WEB-INF/jsp/xpathresultpage.jsp
    	return "xpathresultpage";
	}
    
}
