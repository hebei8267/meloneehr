package org.krams.tutorial.job;

public interface Worker {
	
	public void work();
	
}
